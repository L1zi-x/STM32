#include "stm32f10x.h"                  // Device header
#include "Motor.h"
#include "Delay.h"
void Car_Init(){
	Motor_Init();
}

// 直行
void Go_Ahead(){
	Motor_SetLeftSpeed(30);
	Motor_SetRightSpeed(30);
}

// 小角度左转：左轮减速停转，右轮保持
void Turn_Left_Small(){
	Motor_SetLeftSpeed(50);
	Motor_SetRightSpeed(-25);
}

// 大角度左转：左轮强力反转，右轮全速
void Turn_Left_Big(){
	Motor_SetLeftSpeed(60);
	Motor_SetRightSpeed(-20);
}

// 小角度右转
void Turn_Right_Small(){
	Motor_SetRightSpeed(50);
	Motor_SetLeftSpeed(-25);
}

// 大角度右转
void Turn_Right_Big(){
	Motor_SetRightSpeed(60);
	Motor_SetLeftSpeed(-20);
}

void Car_Stop(){
	Motor_SetLeftSpeed(0);
	Motor_SetRightSpeed(0);
}