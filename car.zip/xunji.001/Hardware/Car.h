#ifndef __CAR_H
#define __CAR_H
void Car_Init();
void Turn_Left_Big();
void Turn_Left_Small();
void Go_Ahead();
void Car_Stop();
void Turn_Right_Small();
void Turn_Right_Big();
#endif