#include "stm32f10x.h"
#include "Delay.h"
#include "PWM.h"
#include "Car.h"
#include "Track.h"
#include "Motor.h"

uint16_t Data1;

int main(void)
{ 
	Car_Init();
	Motor_Init();
	Infrared_Init();
    
    uint8_t last_left = 1, last_mid = 1, last_right = 1;
    
    uint8_t last_state = 0xFF;  // 上一次的传感器组合状态，初始瞎设一个
    uint16_t steady_cnt = 0;    // 状态持续计数器

    #define STOP_STEADY_CNT  100 //计数器，满了就停

	while (1)
	{
        uint8_t left1, mid1, right1;
        uint8_t left2, mid2, right2;
        
        // 采样1
        left1  = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8);
        mid1   = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6);
        right1 = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7);
        
        Delay_ms(5);
        
        // 采样2
        left2  = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8);
        mid2   = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_6);
        right2 = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7);
        
        // 消抖
        uint8_t left  = (left1 == left2)   ? left2  : last_left;
        uint8_t mid   = (mid1 == mid2)     ? mid2   : last_mid;
        uint8_t right = (right1 == right2) ? right2 : last_right;
        
        last_left = left;
        last_mid = mid;
        last_right = right;

        // 状态持续不变终点检测
        uint8_t current_state = (left << 2) | (mid << 1) | right;
        
        if(current_state == last_state)
        {
            steady_cnt++;  // 状态不变计数器累加
            // 达到阈值强制停车
            if(steady_cnt >= STOP_STEADY_CNT)
            {
                Car_Stop();
                while(1);  // 停车后死循环
            }
        }
        else
        {
            steady_cnt = 0;  // 状态变化计数器清零
            last_state = current_state;
        }

		//控制逻辑部分

        if(left == 1 && mid == 1 && right == 1)
        {
            Car_Stop();
        }
        else if(left == 0 && mid == 1 && right == 1)
        {
            Turn_Left_Big();
        }
        else if(left == 1 && mid == 1 && right == 0)
        {
            Turn_Right_Big();
        }
        else if(left == 1 && mid == 0 && right == 0)
        {
            Turn_Left_Small();
        }
        else if(left == 0 && mid == 0 && right == 1)
        {
            Turn_Right_Small();
        }
        else
        {
            Go_Ahead();
        }
        
        Delay_ms(20);
	}
}